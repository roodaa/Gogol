"""
Module d'indexation des documents
"""

from src.indexer.indexer import Indexer

__all__ = ['Indexer']
