"""
Module de ranking pour le moteur de recherche Gogol

Ce module implémente les algorithmes de ranking qui permettent d'ordonner
les résultats de recherche par pertinence. Il utilise principalement la
similarité cosinus (cosine similarity) pour comparer les documents aux requêtes.

Auteur: Romaric Dacosse
Projet: Gogol - Moteur de recherche éducatif
"""

import math
from typing import Dict, List, Tuple
from collections import defaultdict


class Ranker:
    """
    Classe responsable du calcul des scores de pertinence et du ranking des documents.
    
    Le ranking est basé sur la similarité cosinus entre le vecteur TF-IDF de la requête
    et les vecteurs TF-IDF des documents indexés.
    
    Concepts clés:
    --------------
    - Vecteur TF-IDF : Représentation numérique d'un texte où chaque dimension
      correspond à un terme, et la valeur est son score TF-IDF
    
    - Cosine Similarity : Mesure l'angle entre deux vecteurs. Plus l'angle est
      petit (cosinus proche de 1), plus les documents sont similaires.
      Formule: cos(θ) = (A · B) / (||A|| × ||B||)
    
    Attributs:
    ----------
    inverted_index : dict
        L'index inversé contenant les termes et leurs scores TF-IDF par document
        Structure: {terme: {doc_id: tf_idf_score}}
    
    document_norms : dict
        Normes (longueurs) des vecteurs de documents, pré-calculées pour optimisation
        Structure: {doc_id: norme}
    """
    
    def __init__(self, inverted_index: Dict[str, Dict[str, float]]):
        """
        Initialise le ranker avec l'index inversé.
        
        Paramètres:
        -----------
        inverted_index : dict
            Index inversé avec scores TF-IDF
            Format: {terme: {doc_id: tf_idf_score}}
        """
        self.inverted_index = inverted_index
        
        # Pré-calcul des normes des documents pour optimiser les calculs de similarité
        # La norme d'un vecteur est sa "longueur" : ||v|| = sqrt(v1² + v2² + ... + vn²)
        self.document_norms = self._compute_document_norms()
    
    def _compute_document_norms(self) -> Dict[str, float]:
        """
        Calcule et retourne les normes de tous les documents.
        
        La norme (ou magnitude) d'un document est la racine carrée de la somme
        des carrés de tous ses scores TF-IDF. Cette valeur représente la "longueur"
        du vecteur document dans l'espace multidimensionnel des termes.
        
        Pourquoi pré-calculer ?
        ------------------------
        Les normes des documents ne changent pas entre les requêtes, donc on les
        calcule une seule fois au démarrage pour accélérer les recherches.
        
        Formule:
        --------
        ||doc|| = sqrt(Σ(tf_idf_i²)) pour tous les termes i du document
        
        Retourne:
        ---------
        dict
            Dictionnaire {doc_id: norme}
        
        Exemple:
        --------
        Document contenant les mots "python" et "java" avec scores TF-IDF:
        - python: 0.8
        - java: 0.6
        
        Norme = sqrt(0.8² + 0.6²) = sqrt(0.64 + 0.36) = sqrt(1.0) = 1.0
        """
        document_norms = defaultdict(float)
        
        # Pour chaque terme dans l'index inversé
        for term, doc_scores in self.inverted_index.items():
            # Pour chaque document contenant ce terme
            for doc_id, tf_idf_score in doc_scores.items():
                # On ajoute le carré du score TF-IDF à la somme pour ce document
                # (on appliquera la racine carrée à la fin)
                document_norms[doc_id] += tf_idf_score ** 2
        
        # Application de la racine carrée pour obtenir la norme finale
        # Utilisation de math.sqrt car plus rapide que **0.5
        for doc_id in document_norms:
            document_norms[doc_id] = math.sqrt(document_norms[doc_id])
        
        return dict(document_norms)
    
    def _compute_query_vector(self, query_terms: List[str]) -> Tuple[Dict[str, float], float]:
        """
        Calcule le vecteur TF-IDF de la requête et sa norme.
        
        Pour une requête, on utilise une version simplifiée du TF-IDF:
        - TF : fréquence du terme dans la requête (souvent 1 si le terme apparaît)
        - IDF : on réutilise l'IDF calculé lors de l'indexation
        
        Paramètres:
        -----------
        query_terms : list
            Liste des termes de la requête (déjà tokenisés et normalisés)
        
        Retourne:
        ---------
        tuple
            (vecteur_requête, norme_requête)
            - vecteur_requête : dict {terme: tf_idf_score}
            - norme_requête : float, magnitude du vecteur requête
        
        Exemple:
        --------
        Requête: "python tutorial python"
        Termes: ["python", "tutorial", "python"]
        
        TF pour "python" = 2/3 = 0.667 (apparaît 2 fois sur 3 termes)
        TF pour "tutorial" = 1/3 = 0.333 (apparaît 1 fois sur 3 termes)
        """
        # Dictionnaire pour stocker les scores TF-IDF de la requête
        query_vector = {}
        
        # Comptage des occurrences de chaque terme dans la requête (TF)
        term_frequencies = defaultdict(int)
        for term in query_terms:
            term_frequencies[term] += 1
        
        # Calcul du TF-IDF pour chaque terme de la requête
        query_length = len(query_terms)  # Nombre total de termes dans la requête
        
        for term, freq in term_frequencies.items():
            # Vérifier si le terme existe dans notre index
            if term in self.inverted_index:
                # TF : fréquence normalisée du terme dans la requête
                tf = freq / query_length if query_length > 0 else 0
                
                # IDF : on utilise l'IDF moyen des documents contenant ce terme
                # (approximation simple, on pourrait aussi calculer un IDF global)
                idf_scores = list(self.inverted_index[term].values())
                avg_idf = sum(idf_scores) / len(idf_scores) if idf_scores else 0
                
                # TF-IDF de la requête
                query_vector[term] = tf * avg_idf
        
        # Calcul de la norme du vecteur requête
        # ||query|| = sqrt(Σ(tf_idf_i²))
        query_norm = math.sqrt(sum(score ** 2 for score in query_vector.values()))
        
        return query_vector, query_norm
    
    def cosine_similarity(
        self, 
        query_vector: Dict[str, float], 
        query_norm: float,
        doc_id: str
    ) -> float:
        """
        Calcule la similarité cosinus entre une requête et un document.
        
        La similarité cosinus mesure l'angle entre deux vecteurs dans un espace
        multidimensionnel. Elle est indépendante de la longueur des documents,
        ce qui est idéal pour comparer des textes de tailles différentes.
        
        Formule mathématique:
        ---------------------
        cos(θ) = (A · B) / (||A|| × ||B||)
        
        Où:
        - A · B est le produit scalaire (dot product) des vecteurs
        - ||A|| et ||B|| sont les normes (magnitudes) des vecteurs
        
        Interprétation des valeurs:
        ---------------------------
        - 1.0  : Documents identiques (angle de 0°)
        - 0.5  : Documents moyennement similaires (angle de 60°)
        - 0.0  : Documents sans termes en commun (angle de 90°)
        - -1.0 : Documents opposés (angle de 180°, rare en recherche textuelle)
        
        Paramètres:
        -----------
        query_vector : dict
            Vecteur TF-IDF de la requête {terme: score}
        query_norm : float
            Norme (magnitude) du vecteur requête
        doc_id : str
            Identifiant du document à comparer
        
        Retourne:
        ---------
        float
            Score de similarité entre 0 et 1 (généralement)
        
        Exemple de calcul:
        ------------------
        Requête: ["python", "tutorial"] avec vecteur [0.8, 0.6]
        Document: contient aussi ["python", "tutorial"] avec vecteur [0.7, 0.5]
        
        Produit scalaire = 0.8*0.7 + 0.6*0.5 = 0.56 + 0.30 = 0.86
        ||query|| = 1.0 (normalisé)
        ||doc|| = sqrt(0.7² + 0.5²) = 0.86
        
        Similarité = 0.86 / (1.0 * 0.86) = 1.0 (très similaires)
        """
        # Vérification: le document doit exister dans nos normes pré-calculées
        if doc_id not in self.document_norms:
            return 0.0
        
        # Récupération de la norme du document (pré-calculée)
        doc_norm = self.document_norms[doc_id]
        
        # Cas particulier: si l'une des normes est nulle, la similarité est 0
        # (évite une division par zéro)
        if query_norm == 0 or doc_norm == 0:
            return 0.0
        
        # Calcul du produit scalaire (dot product) entre requête et document
        # On ne calcule que pour les termes communs (optimisation importante!)
        dot_product = 0.0
        
        for term, query_score in query_vector.items():
            # Si le terme de la requête existe dans le document
            if term in self.inverted_index and doc_id in self.inverted_index[term]:
                # Score TF-IDF du terme dans le document
                doc_score = self.inverted_index[term][doc_id]
                
                # Contribution au produit scalaire
                dot_product += query_score * doc_score
        
        # Calcul final de la similarité cosinus
        # cos(θ) = produit_scalaire / (norme_query × norme_doc)
        similarity = dot_product / (query_norm * doc_norm)
        
        return similarity
    
    def rank(
        self, 
        query_terms: List[str], 
        top_k: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Classe les documents par pertinence pour une requête donnée.
        
        Algorithme:
        -----------
        1. Construire le vecteur TF-IDF de la requête
        2. Calculer la similarité cosinus avec tous les documents candidats
        3. Trier les documents par score décroissant
        4. Retourner les top_k meilleurs résultats
        
        Optimisations:
        --------------
        - On ne calcule la similarité que pour les documents contenant au moins
          un terme de la requête (les autres auront forcément un score de 0)
        - Les normes des documents sont pré-calculées
        
        Paramètres:
        -----------
        query_terms : list
            Liste des termes de la requête (normalisés)
        top_k : int, optionnel (défaut: 10)
            Nombre de résultats à retourner
        
        Retourne:
        ---------
        list
            Liste de tuples (doc_id, score) triés par score décroissant
            Limité aux top_k meilleurs résultats
        
        Exemple:
        --------
        >>> ranker.rank(["python", "tutorial"], top_k=5)
        [
            ("doc_123", 0.95),  # Très pertinent
            ("doc_456", 0.87),  # Très pertinent
            ("doc_789", 0.72),  # Moyennement pertinent
            ("doc_012", 0.45),  # Peu pertinent
            ("doc_345", 0.23)   # Peu pertinent
        ]
        """
        # Étape 1: Construction du vecteur requête et calcul de sa norme
        query_vector, query_norm = self._compute_query_vector(query_terms)
        
        # Si la requête est vide ou ne contient aucun terme connu, retourner liste vide
        if not query_vector or query_norm == 0:
            return []
        
        # Étape 2: Identification des documents candidats
        # (documents contenant au moins un terme de la requête)
        candidate_docs = set()
        for term in query_vector.keys():
            if term in self.inverted_index:
                # Ajouter tous les documents contenant ce terme
                candidate_docs.update(self.inverted_index[term].keys())
        
        # Si aucun document candidat, retourner liste vide
        if not candidate_docs:
            return []
        
        # Étape 3: Calcul des scores de similarité pour tous les candidats
        doc_scores = []
        for doc_id in candidate_docs:
            # Calcul de la similarité cosinus entre requête et document
            similarity = self.cosine_similarity(query_vector, query_norm, doc_id)
            
            # Ajout du résultat uniquement si le score est supérieur à 0
            # (optimisation: évite de stocker des résultats non pertinents)
            if similarity > 0:
                doc_scores.append((doc_id, similarity))
        
        # Étape 4: Tri des résultats par score décroissant
        # key=lambda x: x[1] signifie "trier selon le 2ème élément du tuple (le score)"
        # reverse=True donne l'ordre décroissant (meilleurs scores en premier)
        doc_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Étape 5: Retour des top_k meilleurs résultats
        # L'opérateur [:top_k] limite la liste aux k premiers éléments
        return doc_scores[:top_k]
    
    def batch_rank(
        self,
        queries: List[List[str]],
        top_k: int = 10
    ) -> List[List[Tuple[str, float]]]:
        """
        Traite plusieurs requêtes en batch (par lot).
        
        Utile pour:
        -----------
        - Évaluation de performance du moteur de recherche
        - Traitement de multiples requêtes utilisateur en parallèle
        - Tests et benchmarks
        
        Paramètres:
        -----------
        queries : list of list
            Liste de requêtes, chaque requête étant une liste de termes
        top_k : int, optionnel (défaut: 10)
            Nombre de résultats par requête
        
        Retourne:
        ---------
        list of list
            Liste de listes de résultats, une par requête
        
        Exemple:
        --------
        >>> queries = [
        ...     ["python", "tutorial"],
        ...     ["machine", "learning"]
        ... ]
        >>> ranker.batch_rank(queries, top_k=3)
        [
            [("doc_1", 0.95), ("doc_2", 0.87), ("doc_3", 0.72)],
            [("doc_4", 0.89), ("doc_5", 0.76), ("doc_6", 0.65)]
        ]
        """
        results = []
        for query_terms in queries:
            results.append(self.rank(query_terms, top_k))
        return results


# ============================================================================
# Fonctions utilitaires pour le ranking
# ============================================================================

def print_ranked_results(
    ranked_results: List[Tuple[str, float]],
    max_display: int = 10
) -> None:
    """
    Affiche les résultats de ranking de manière lisible.
    
    Utile pour le debugging et la visualisation des résultats.
    
    Paramètres:
    -----------
    ranked_results : list
        Liste de tuples (doc_id, score)
    max_display : int, optionnel (défaut: 10)
        Nombre maximum de résultats à afficher
    
    Exemple d'affichage:
    --------------------
    Résultats de recherche (5 documents trouvés):
    
    1. doc_python_tutorial_01.html
       Score: 0.9523
       ████████████████████░ 95.23%
    
    2. doc_python_basics.html
       Score: 0.8745
       █████████████████░░░░ 87.45%
    """
    print(f"\nRésultats de recherche ({len(ranked_results)} documents trouvés):\n")
    
    for i, (doc_id, score) in enumerate(ranked_results[:max_display], 1):
        # Barre de progression visuelle
        bar_length = 20
        filled_length = int(bar_length * score)
        bar = '█' * filled_length + '░' * (bar_length - filled_length)
        
        print(f"{i}. {doc_id}")
        print(f"   Score: {score:.4f}")
        print(f"   {bar} {score*100:.2f}%\n")


def normalize_scores(
    ranked_results: List[Tuple[str, float]]
) -> List[Tuple[str, float]]:
    """
    Normalise les scores entre 0 et 1 (si ce n'est pas déjà le cas).
    
    La cosine similarity donne déjà des scores entre 0 et 1 en général,
    mais cette fonction peut être utile si on combine plusieurs métriques.
    
    Paramètres:
    -----------
    ranked_results : list
        Liste de tuples (doc_id, score)
    
    Retourne:
    ---------
    list
        Liste de tuples avec scores normalisés
    """
    if not ranked_results:
        return []
    
    # Trouver le score maximum
    max_score = max(score for _, score in ranked_results)
    
    # Éviter la division par zéro
    if max_score == 0:
        return ranked_results
    
    # Normaliser tous les scores
    normalized = [(doc_id, score / max_score) for doc_id, score in ranked_results]
    
    return normalized


# ============================================================================
# Exemple d'utilisation
# ============================================================================

if __name__ == "__main__":
    """
    Exemple d'utilisation du Ranker avec un index inversé simulé.
    
    Cet exemple montre comment:
    1. Créer un index inversé avec scores TF-IDF
    2. Initialiser le Ranker
    3. Effectuer une recherche et afficher les résultats
    """
    
    # Simulation d'un index inversé avec scores TF-IDF
    # Structure: {terme: {doc_id: tf_idf_score}}
    sample_index = {
        "python": {
            "doc1": 0.85,  # Document très pertinent pour "python"
            "doc2": 0.65,  # Document moyennement pertinent
            "doc3": 0.15   # Document peu pertinent
        },
        "tutorial": {
            "doc1": 0.75,  # Document très pertinent pour "tutorial"
            "doc2": 0.25,  # Document peu pertinent
            "doc4": 0.55   # Document moyennement pertinent
        },
        "java": {
            "doc2": 0.80,  # Document pertinent pour "java"
            "doc5": 0.70   # Document pertinent
        },
        "programming": {
            "doc1": 0.60,
            "doc2": 0.55,
            "doc3": 0.45,
            "doc4": 0.50,
            "doc5": 0.65
        }
    }
    
    # Création du ranker
    print("Initialisation du Ranker...")
    ranker = Ranker(sample_index)
    
    # Affichage des normes des documents (pour information)
    print("\nNormes des documents calculées:")
    for doc_id, norm in sorted(ranker.document_norms.items()):
        print(f"  {doc_id}: {norm:.4f}")
    
    # Exemple de recherche 1: requête simple
    print("\n" + "="*60)
    print("Recherche: 'python tutorial'")
    print("="*60)
    
    query = ["python", "tutorial"]
    results = ranker.rank(query, top_k=5)
    print_ranked_results(results)
    
    # Exemple de recherche 2: autre requête
    print("\n" + "="*60)
    print("Recherche: 'java programming'")
    print("="*60)
    
    query = ["java", "programming"]
    results = ranker.rank(query, top_k=5)
    print_ranked_results(results)
    
    # Exemple de batch ranking
    print("\n" + "="*60)
    print("Batch Ranking: plusieurs requêtes")
    print("="*60)
    
    queries = [
        ["python"],
        ["tutorial"],
        ["python", "tutorial", "programming"]
    ]
    
    batch_results = ranker.batch_rank(queries, top_k=3)
    
    for i, (query, results) in enumerate(zip(queries, batch_results), 1):
        print(f"\nRequête {i}: {' '.join(query)}")
        print("-" * 40)
        for j, (doc_id, score) in enumerate(results, 1):
            print(f"  {j}. {doc_id}: {score:.4f}")