"""
Module du moteur de recherche
"""
