"""
Module de crawling web
"""
from .crawler import Crawler

__all__ = ['Crawler']
