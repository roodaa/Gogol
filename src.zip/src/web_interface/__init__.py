"""
Module de l'interface web
"""
